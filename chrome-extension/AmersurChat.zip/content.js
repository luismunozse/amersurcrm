const f={debug:(...t)=>{},warn:(t,...e)=>console.warn(`[WhatsApp] ${t}`,...e),error:(t,e)=>console.error(`[WhatsApp] ${t}`,e||"")},c={chatHeader:['[data-testid="conversation-header"]',"#main header","header"],headerContactSpan:['[data-testid="conversation-info-header"] span[dir="auto"]','[data-testid="conversation-title"] span[dir="auto"]','#main header span[title][dir="auto"]','#main header span[dir="auto"]','header span[title][dir="auto"]','header span[dir="auto"]'],headerInfoButton:['[data-testid="conversation-info-header"]','[data-testid="contact-info-drawer"]','header [role="button"]'],incomingMessage:['[data-testid="msg-container"].message-in',".message-in",'div[data-id][class*="message-in"]'],messageText:["span.selectable-text.copyable-text span",'span.selectable-text span[dir="ltr"]',"span.selectable-text span",'span[dir="ltr"]'],messageMeta:["[data-pre-plain-text]"],selectableText:["span.selectable-text","span.selectable-text span",".selectable-text"],chatInput:['[data-testid="conversation-compose-box-input"]','footer [contenteditable="true"][data-tab="10"]','footer [contenteditable="true"]','[contenteditable="true"][data-tab="10"]','div[contenteditable="true"][role="textbox"]'],messageDataId:["#main [data-id]"]};function h(t,e=document){for(const n of t)try{const a=e.querySelector(n);if(a)return a}catch{}return null}function u(t,e=document){for(const n of t)try{const a=e.querySelectorAll(n);if(a.length>0)return Array.from(a)}catch{}return[]}function b(){const t=window.location.href.match(/\/(\d{10,15})(@lid|@|$)/);if(t!=null&&t[1]&&t[2]!=="@lid")return"+"+t[1];const e=h(c.headerInfoButton);if(e){const r=(e.getAttribute("aria-label")||e.getAttribute("title")||"").match(/\+?[\d\s()-]+/);if(r&&r[0].replace(/[^\d]/g,"").length>=10)return r[0].replace(/[^\d+]/g,"")}const n=M();return n||null}function M(){var e;const t=u(c.headerContactSpan);for(const n of t){const a=(e=n.textContent)==null?void 0:e.trim();if(!a)continue;const r=a.match(/\+?[\d\s()-]+/);if(!r)continue;const s=r[0].replace(/[^\d+]/g,"");if(s.replace(/\+/g,"").length>=10)return s.startsWith("+")?s:"+"+s}return null}function v(t){const e=(t||"").replace(/^~\s*/,"").trim();return!e||e.startsWith("@")||/^\+?[\d\s()-]+$/.test(e)||!/[a-zA-ZáéíóúñÁÉÍÓÚÑ]/.test(e)?null:e}function x(){var n;const t=u(c.headerContactSpan),e=v((n=t[0])==null?void 0:n.textContent);return e||null}function E(){var e;const t=u(c.headerContactSpan);for(const n of t){const a=(e=n.textContent)==null?void 0:e.trim();if(!a)continue;const r=a.match(/^@([a-z0-9._]{3,30})$/i);if(r)return r[1].toLowerCase()}return null}function H(){const t=u(c.messageDataId);for(const e of t){const a=(e.getAttribute("data-id")||"").match(/(\d{6,20})@lid/);if(a)return`${a[1]}@lid`}return null}function O(){var t,e;return((e=(t=u(c.headerContactSpan)[0])==null?void 0:t.textContent)==null?void 0:e.trim())||""}let C=null,T=null;function N(){const t=O(),e=H();if(!e)return null;const n=C===t&&T===e;return C=t,T=e,n?e:null}function D(){const t=window.location.href.match(/\/(\d{10,15})(@lid|@|$)/);if(t!=null&&t[1]&&t[2]!=="@lid")return t[1];const e=M();if(e)return e.replace(/[^\d]/g,"");const n=N();return n||null}function A(t){return(t||"").replace(/\D/g,"")}function w(t){const e=(t||"").match(/\]\s*(.*?):\s*$/);return e?e[1].trim():""}function L(t,e,n,a){if(!t)return!1;const r=A(t);return e&&r.length>=8?r.slice(-8)===e.slice(-8):a&&t.replace(/^@/,"").toLowerCase()===a.toLowerCase()?!0:!!n&&t===n}function I(t){return t.replace(/\s*\d{1,2}:\d{2}\s*(a\.?\s*m\.?|p\.?\s*m\.?|AM|PM)?\s*$/i,"").trim()}function U(){var s;const t=A(b()),e=(x()||"").trim(),n=E()||"",a=u(c.messageMeta);for(let o=a.length-1;o>=0;o--){const d=w(a[o].getAttribute("data-pre-plain-text"));if(!L(d,t,e,n))continue;const i=h(c.selectableText,a[o])||a[o],l=I((i.textContent||"").trim());if(l&&m(l))return l}const r=u(c.incomingMessage);for(let o=r.length-1;o>=Math.max(0,r.length-5);o--){const d=u(c.messageText,r[o]);for(const i of d){const l=(s=i.textContent)==null?void 0:s.trim();if(l&&m(l))return l}}return f.warn(`getLastReceivedMessage: no se encontró mensaje entrante. Bloques data-pre-plain-text: ${a.length}, contacto: ${t||e||"desconocido"}. ¿Cambió el DOM de WhatsApp Web? Revisar SELECTORS.messageMeta/selectableText.`),null}function m(t){return!(t.length<2||/^\d{1,2}:\d{2}(\s*(a\.\s*m\.|p\.\s*m\.|AM|PM))?\.?$/.test(t)||/^(Enviado|Entregado|Le[íi]do|Visto|Delivered|Read|Sent)$/i.test(t)||/^(Ayer|Hoy|Yesterday|Today)$/i.test(t))}const W=30,y=120,$=/\+?\d[\d\s().-]{6,17}\d/g;function P(t){const e=t.trim().startsWith("+"),n=t.replace(/\D/g,"");return n.length<8||n.length>15?null:n.length===9&&n.startsWith("9")?{phone:`+51${n}`,digits:n}:e?{phone:`+${n}`,digits:n}:{phone:n,digits:n}}const k=/\d,\d/;function z(t){const e=t.matchAll($);for(const n of e){const a=n[0],r=n.index??t.indexOf(a),s=t.slice(Math.max(0,r-12),r+a.length+12);if(/S\/|\$/.test(s)||k.test(s))continue;const o=P(a);if(!o)continue;const d=/^\d+$/.test(a.trim());if(!(o.digits.length===8&&d&&/dni/i.test(s)))return o.phone}return null}function B(t){return t.length>y?`${t.slice(0,y)}…`:t}function q(){const t=A(b()),e=(x()||"").trim(),n=E()||"",a=u(c.messageMeta),r=Math.max(0,a.length-W);for(let s=a.length-1;s>=r;s--){const o=w(a[s].getAttribute("data-pre-plain-text"));if(!L(o,t,e,n))continue;const d=h(c.selectableText,a[s])||a[s],i=I((d.textContent||"").trim());if(!i||!m(i))continue;const l=z(i);if(l)return{phone:l,sourceText:B(i)}}return null}function _(){const t=b(),e=x(),n=D(),a=E();return!t&&!n&&!a?null:{phone:t,name:e,chatId:n||a||"unknown",username:a}}function X(t){try{const e=h(c.chatInput);if(!e)return f.warn("No se encontró el input de WhatsApp con ningún selector"),!1;e.focus();const n=t.substring(0,20),a=()=>(e.textContent||"").includes(n);if(document.execCommand("insertText",!1,t)&&a())return!0;const s=new InputEvent("input",{bubbles:!0,cancelable:!0,inputType:"insertText",data:t});e.textContent=t,e.dispatchEvent(s),e.dispatchEvent(new Event("change",{bubbles:!0}));const o=a();return o||f.warn("insertTextIntoWhatsApp: el input no quedó con el texto tras execCommand ni el fallback. ¿Cambió el editor de WhatsApp Web? Revisar SELECTORS.chatInput."),o}catch(e){return f.error("Error insertando texto en WhatsApp",e instanceof Error?e:void 0),!1}}function j(t){let e=null,n=null,a=!1;const r=()=>{if(a)return;const i=_(),l=(i==null?void 0:i.chatId)||null;l!==e&&(e=l,t(i))};r();let s=null;const o=()=>{const i=h(c.chatHeader);!i||i===s||(n==null||n.disconnect(),s=i,n=new MutationObserver(r),n.observe(i,{childList:!0,subtree:!0,characterData:!0}))};o();const d=setInterval(()=>{o(),r()},3e3);return()=>{a=!0,clearInterval(d),n==null||n.disconnect()}}const g=new URL(chrome.runtime.getURL("")).origin;let p=null;function G(t){p&&p.postMessage({type:"AMERSURCHAT_CONTACT_CHANGED",contact:t},g)}const S=6e4,R=500;function F(){return new Promise(t=>{let e=0;const n=setInterval(()=>{const a=document.querySelector("#app");if(a&&a.childNodes.length>0){clearInterval(n),t();return}e+=R,e>=S&&(clearInterval(n),console.warn(`[AmersurChat] #app no apareció tras ${S/1e3}s. Se inyecta el sidebar igual. ¿Cambió el markup de WhatsApp Web?`),t())},R)})}function K(){if(document.getElementById("amersurchat-sidebar"))return;const t=document.createElement("div");t.id="amersurchat-overlay",t.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: calc(100% - 300px);
    height: 100vh;
    background: rgba(0, 0, 0, 0.2);
    z-index: 999998;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.3s ease;
  `;const e=document.createElement("div");e.id="amersurchat-sidebar",e.style.cssText=`
    position: fixed;
    top: 0;
    right: 0;
    width: 300px;
    height: 100vh;
    z-index: 999999;
    background: white;
    box-shadow: -2px 0 12px rgba(0, 0, 0, 0.2);
    transform: translateX(100%);
    transition: transform 0.3s ease;
  `,e.classList.add("amersurchat-hidden");const n=document.createElement("iframe");n.style.cssText=`
    width: 100%;
    height: 100%;
    border: none;
  `,n.allow="clipboard-write",n.src=chrome.runtime.getURL("sidebar.html"),p=n.contentWindow,n.addEventListener("load",()=>{p=n.contentWindow}),e.appendChild(n),document.body.appendChild(t),document.body.appendChild(e);const a=(d=!1)=>{!e.classList.contains("amersurchat-hidden")||d?(e.classList.add("amersurchat-hidden"),e.style.transform="translateX(100%)",t.style.opacity="0",t.style.pointerEvents="none",r.style.right="20px"):(e.classList.remove("amersurchat-hidden"),e.style.transform="translateX(0)",t.style.opacity="1",t.style.pointerEvents="auto",r.style.right="320px")};t.addEventListener("click",()=>a(!0));const r=document.createElement("button");r.id="amersurchat-toggle";const s=chrome.runtime.getURL("icons/icon48.png");r.innerHTML=`
    <img src="${s}" alt="Amersur CRM" style="width: 28px; height: 28px; object-fit: contain;" />
  `,r.title="Amersur CRM",r.style.cssText=`
    position: fixed;
    top: 20px;
    right: 20px;
    width: 44px;
    height: 44px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    cursor: pointer;
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
    z-index: 999998;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
  `,r.addEventListener("mouseenter",()=>{r.style.transform="scale(1.1)",r.style.boxShadow="0 6px 16px rgba(102, 126, 234, 0.6)"}),r.addEventListener("mouseleave",()=>{r.style.transform="scale(1)",r.style.boxShadow="0 4px 12px rgba(102, 126, 234, 0.4)"}),r.addEventListener("click",()=>a());const o=document.createElement("div");o.id="amersurchat-badge",o.style.cssText=`
    position: absolute;
    top: -4px;
    right: -4px;
    min-width: 20px;
    height: 20px;
    border-radius: 10px;
    background: #ef4444;
    color: white;
    font-size: 11px;
    font-weight: bold;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 0 6px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
    border: 2px solid white;
  `,r.appendChild(o),document.body.appendChild(r)}function V(t){const e=document.getElementById("amersurchat-badge");e&&(t>0?(e.textContent=t>9?"9+":t.toString(),e.style.display="flex"):e.style.display="none")}F().then(()=>{K(),j(t=>G(t))});window.addEventListener("message",t=>{if(t.origin!==g||!t.data||typeof t.data!="object"||p&&t.source!==p)return;const e=n=>{t.source&&typeof t.source.postMessage=="function"&&t.source.postMessage(n,g)};switch(t.data.type){case"AMERSURCHAT_GET_CONTACT":{const n=_();e({type:"AMERSURCHAT_CONTACT_INFO",contact:n});break}case"AMERSURCHAT_INSERT_TEMPLATE":{const{text:n}=t.data;if(n){const a=X(n);e({type:"AMERSURCHAT_TEMPLATE_INSERTED",success:a})}break}case"AMERSURCHAT_UPDATE_BADGE":{const{count:n}=t.data;typeof n=="number"&&V(n);break}case"AMERSURCHAT_GET_LAST_MESSAGE":{const n=U();e({type:"AMERSURCHAT_LAST_MESSAGE",message:n});break}case"AMERSURCHAT_DETECT_SHARED_PHONE":{const n=q();e({type:"AMERSURCHAT_SHARED_PHONE",detection:n});break}}});
