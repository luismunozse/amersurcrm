const f={debug:(...t)=>{},warn:(t,...e)=>console.warn(`[WhatsApp] ${t}`,...e),error:(t,e)=>console.error(`[WhatsApp] ${t}`,e||"")},c={chatHeader:["header",'[data-testid="conversation-header"]',"#main header"],headerContactSpan:['[data-testid="conversation-info-header"] span[dir="auto"]','[data-testid="conversation-title"] span[dir="auto"]','header span[title][dir="auto"]','header span[dir="auto"]'],headerInfoButton:['[data-testid="conversation-info-header"]','[data-testid="contact-info-drawer"]','header [role="button"]'],incomingMessage:['[data-testid="msg-container"].message-in',".message-in",'div[data-id][class*="message-in"]'],messageText:["span.selectable-text.copyable-text span",'span.selectable-text span[dir="ltr"]',"span.selectable-text span",'span[dir="ltr"]'],messageMeta:["[data-pre-plain-text]"],selectableText:["span.selectable-text","span.selectable-text span",".selectable-text"],chatInput:['[data-testid="conversation-compose-box-input"]','footer [contenteditable="true"][data-tab="10"]','footer [contenteditable="true"]','[contenteditable="true"][data-tab="10"]','div[contenteditable="true"][role="textbox"]'],messageDataId:["#main [data-id]"]};function p(t,e=document){for(const n of t)try{const r=e.querySelector(n);if(r)return r}catch{}return null}function u(t,e=document){for(const n of t)try{const r=e.querySelectorAll(n);if(r.length>0)return Array.from(r)}catch{}return[]}function b(){const t=window.location.href.match(/\/(\d{10,15})(@lid|@|$)/);if(t!=null&&t[1]&&t[2]!=="@lid")return"+"+t[1];const e=p(c.headerInfoButton);if(e){const a=(e.getAttribute("aria-label")||e.getAttribute("title")||"").match(/\+?[\d\s()-]+/);if(a&&a[0].replace(/[^\d]/g,"").length>=10)return a[0].replace(/[^\d+]/g,"")}const n=M();return n||null}function M(){var e;const t=u(c.headerContactSpan);for(const n of t){const r=(e=n.textContent)==null?void 0:e.trim();if(!r)continue;const a=r.match(/\+?[\d\s()-]+/);if(!a)continue;const o=a[0].replace(/[^\d+]/g,"");if(o.replace(/\+/g,"").length>=10)return o.startsWith("+")?o:"+"+o}return null}function L(t){const e=(t||"").replace(/^~\s*/,"").trim();return!e||e.startsWith("@")||/^\+?[\d\s()-]+$/.test(e)||!/[a-zA-ZáéíóúñÁÉÍÓÚÑ]/.test(e)?null:e}function x(){var n;const t=u(c.headerContactSpan),e=L((n=t[0])==null?void 0:n.textContent);return e||null}function E(){var e;const t=u(c.headerContactSpan);for(const n of t){const r=(e=n.textContent)==null?void 0:e.trim();if(!r)continue;const a=r.match(/^@([a-z0-9._]{3,30})$/i);if(a)return a[1].toLowerCase()}return null}function I(){const t=u(c.messageDataId);for(const e of t){const r=(e.getAttribute("data-id")||"").match(/(\d{6,20})@lid/);if(r)return`${r[1]}@lid`}return null}function _(){var t,e;return((e=(t=u(c.headerContactSpan)[0])==null?void 0:t.textContent)==null?void 0:e.trim())||""}let C=null,T=null;function H(){const t=_(),e=I();if(!e)return null;const n=C===t&&T===e;return C=t,T=e,n?e:null}function N(){const t=window.location.href.match(/\/(\d{10,15})(@lid|@|$)/);if(t!=null&&t[1]&&t[2]!=="@lid")return t[1];const e=M();if(e)return e.replace(/[^\d]/g,"");const n=H();return n||null}function y(t){return(t||"").replace(/\D/g,"")}function R(t){const e=(t||"").match(/\]\s*(.*?):\s*$/);return e?e[1].trim():""}function w(t,e,n,r){if(!t)return!1;const a=y(t);return e&&a.length>=8?a.slice(-8)===e.slice(-8):r&&t.replace(/^@/,"").toLowerCase()===r.toLowerCase()?!0:!!n&&t===n}function v(t){return t.replace(/\s*\d{1,2}:\d{2}\s*(a\.?\s*m\.?|p\.?\s*m\.?|AM|PM)?\s*$/i,"").trim()}function D(){var o;const t=y(b()),e=(x()||"").trim(),n=E()||"",r=u(c.messageMeta);for(let s=r.length-1;s>=0;s--){const i=R(r[s].getAttribute("data-pre-plain-text"));if(!w(i,t,e,n))continue;const l=p(c.selectableText,r[s])||r[s],d=v((l.textContent||"").trim());if(d&&m(d))return d}const a=u(c.incomingMessage);for(let s=a.length-1;s>=Math.max(0,a.length-5);s--){const i=u(c.messageText,a[s]);for(const l of i){const d=(o=l.textContent)==null?void 0:o.trim();if(d&&m(d))return d}}return f.warn(`getLastReceivedMessage: no se encontró mensaje entrante. Bloques data-pre-plain-text: ${r.length}, contacto: ${t||e||"desconocido"}. ¿Cambió el DOM de WhatsApp Web? Revisar SELECTORS.messageMeta/selectableText.`),null}function m(t){return!(t.length<2||/^\d{1,2}:\d{2}(\s*(a\.\s*m\.|p\.\s*m\.|AM|PM))?\.?$/.test(t)||/^(Enviado|Entregado|Le[íi]do|Visto|Delivered|Read|Sent)$/i.test(t)||/^(Ayer|Hoy|Yesterday|Today)$/i.test(t))}const U=30,S=120,O=/\+?\d[\d\s().-]{6,17}\d/g;function $(t){const e=t.trim().startsWith("+"),n=t.replace(/\D/g,"");return n.length<8||n.length>15?null:n.length===9&&n.startsWith("9")?{phone:`+51${n}`,digits:n}:e?{phone:`+${n}`,digits:n}:{phone:n,digits:n}}function P(t){const e=t.matchAll(O);for(const n of e){const r=n[0],a=n.index??t.indexOf(r),o=t.slice(Math.max(0,a-12),a+r.length+12);if(/S\/|\$|,/.test(o))continue;const s=$(r);if(!s)continue;const i=/^\d+$/.test(r.trim());if(!(s.digits.length===8&&i&&/dni/i.test(o)))return s.phone}return null}function W(t){return t.length>S?`${t.slice(0,S)}…`:t}function k(){const t=y(b()),e=(x()||"").trim(),n=E()||"",r=u(c.messageMeta),a=Math.max(0,r.length-U);for(let o=r.length-1;o>=a;o--){const s=R(r[o].getAttribute("data-pre-plain-text"));if(!w(s,t,e,n))continue;const i=p(c.selectableText,r[o])||r[o],l=v((i.textContent||"").trim());if(!l||!m(l))continue;const d=P(l);if(d)return{phone:d,sourceText:W(l)}}return null}function A(){const t=b(),e=x(),n=N(),r=E();return!t&&!n&&!r?null:{phone:t,name:e||"Sin nombre",chatId:n||r||"unknown",username:r}}function z(t){var e;try{const n=p(c.chatInput);if(!n)return f.warn("No se encontró el input de WhatsApp con ningún selector"),!1;if(n.focus(),document.execCommand("insertText",!1,t)&&((e=n.textContent)!=null&&e.includes(t.substring(0,20))))return!0;const a=new InputEvent("input",{bubbles:!0,cancelable:!0,inputType:"insertText",data:t});return n.textContent=t,n.dispatchEvent(a),n.dispatchEvent(new Event("change",{bubbles:!0})),!0}catch(n){return f.error("Error insertando texto en WhatsApp",n instanceof Error?n:void 0),!1}}function B(t){let e=null,n=null,r=!1;const a=()=>{if(r)return;const i=A(),l=(i==null?void 0:i.chatId)||null;l!==e&&(e=l,t(i))};a();const o=p(c.chatHeader);o&&(n=new MutationObserver(a),n.observe(o,{childList:!0,subtree:!0,characterData:!0}));const s=setInterval(a,3e3);return()=>{r=!0,clearInterval(s),n==null||n.disconnect()}}const g=new URL(chrome.runtime.getURL("")).origin;let h=null;function q(){if(!h)return;const t=A();h.postMessage({type:"AMERSURCHAT_CONTACT_CHANGED",contact:t},g)}function j(){return new Promise(t=>{const e=setInterval(()=>{const n=document.querySelector("#app");n&&n.childNodes.length>0&&(clearInterval(e),t())},500)})}function G(){if(document.getElementById("amersurchat-sidebar"))return;const t=document.createElement("div");t.id="amersurchat-overlay",t.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: calc(100% - 300px);
    height: 100vh;
    background: rgba(0, 0, 0, 0.2);
    z-index: 999998;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.3s ease;
  `;const e=document.createElement("div");e.id="amersurchat-sidebar",e.style.cssText=`
    position: fixed;
    top: 0;
    right: 0;
    width: 300px;
    height: 100vh;
    z-index: 999999;
    background: white;
    box-shadow: -2px 0 12px rgba(0, 0, 0, 0.2);
    transform: translateX(100%);
    transition: transform 0.3s ease;
  `,e.classList.add("amersurchat-hidden");const n=document.createElement("iframe");n.style.cssText=`
    width: 100%;
    height: 100%;
    border: none;
  `,n.src=chrome.runtime.getURL("sidebar.html"),h=n.contentWindow,n.addEventListener("load",()=>{h=n.contentWindow}),e.appendChild(n),document.body.appendChild(t),document.body.appendChild(e);const r=(i=!1)=>{!e.classList.contains("amersurchat-hidden")||i?(e.classList.add("amersurchat-hidden"),e.style.transform="translateX(100%)",t.style.opacity="0",t.style.pointerEvents="none",a.style.right="20px"):(e.classList.remove("amersurchat-hidden"),e.style.transform="translateX(0)",t.style.opacity="1",t.style.pointerEvents="auto",a.style.right="320px")};t.addEventListener("click",()=>r(!0));const a=document.createElement("button");a.id="amersurchat-toggle";const o=chrome.runtime.getURL("icons/icon48.png");a.innerHTML=`
    <img src="${o}" alt="Amersur CRM" style="width: 28px; height: 28px; object-fit: contain;" />
  `,a.title="Amersur CRM",a.style.cssText=`
    position: fixed;
    top: 20px;
    right: 20px;
    width: 44px;
    height: 44px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    cursor: pointer;
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
    z-index: 999998;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
  `,a.addEventListener("mouseenter",()=>{a.style.transform="scale(1.1)",a.style.boxShadow="0 6px 16px rgba(102, 126, 234, 0.6)"}),a.addEventListener("mouseleave",()=>{a.style.transform="scale(1)",a.style.boxShadow="0 4px 12px rgba(102, 126, 234, 0.4)"}),a.addEventListener("click",()=>r());const s=document.createElement("div");s.id="amersurchat-badge",s.style.cssText=`
    position: absolute;
    top: -4px;
    right: -4px;
    min-width: 20px;
    height: 20px;
    border-radius: 10px;
    background: #ef4444;
    color: white;
    font-size: 11px;
    font-weight: bold;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 0 6px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
    border: 2px solid white;
  `,a.appendChild(s),document.body.appendChild(a)}function X(t){const e=document.getElementById("amersurchat-badge");e&&(t>0?(e.textContent=t>9?"9+":t.toString(),e.style.display="flex"):e.style.display="none")}j().then(()=>{G(),B(()=>q())});window.addEventListener("message",t=>{if(t.origin!==g||!t.data||typeof t.data!="object"||h&&t.source!==h)return;const e=n=>{t.source&&typeof t.source.postMessage=="function"&&t.source.postMessage(n,g)};switch(t.data.type){case"AMERSURCHAT_GET_CONTACT":{const n=A();e({type:"AMERSURCHAT_CONTACT_INFO",contact:n});break}case"AMERSURCHAT_INSERT_TEMPLATE":{const{text:n}=t.data;if(n){const r=z(n);e({type:"AMERSURCHAT_TEMPLATE_INSERTED",success:r})}break}case"AMERSURCHAT_UPDATE_BADGE":{const{count:n}=t.data;typeof n=="number"&&X(n);break}case"AMERSURCHAT_GET_LAST_MESSAGE":{const n=D();e({type:"AMERSURCHAT_LAST_MESSAGE",message:n});break}case"AMERSURCHAT_DETECT_SHARED_PHONE":{const n=k();e({type:"AMERSURCHAT_SHARED_PHONE",detection:n});break}}});
