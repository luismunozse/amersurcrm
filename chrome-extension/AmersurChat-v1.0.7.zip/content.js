function m(){console.log("[WhatsApp] Extrayendo número de teléfono..."),console.log("[WhatsApp] URL actual:",window.location.href);const e=window.location.href.match(/\/(\d{10,15})(@|$)/);if(e&&e[1])return console.log("[WhatsApp] Número extraído de URL:",e[1]),"+"+e[1];const t=document.querySelector('[data-testid="conversation-info-header"]');if(t){console.log("[WhatsApp] Header encontrado, buscando número en atributos...");const a=t.getAttribute("aria-label");if(a){console.log("[WhatsApp] aria-label encontrado:",a);const n=a.match(/\+?[\d\s()-]+/);if(n&&n[0].replace(/[^\d]/g,"").length>=10){const s=n[0].replace(/[^\d+]/g,"");return console.log("[WhatsApp] Número extraído de aria-label:",s),s}}}const o=document.querySelectorAll('header span[dir="auto"]');console.log('[WhatsApp] Spans con dir="auto" encontrados:',o.length);for(const a of o)if(a.textContent){const n=a.textContent.trim();console.log("[WhatsApp] Analizando span:",n);const s=/\+?[\d\s()-]+/,c=n.match(s);if(c){const i=c[0].replace(/[^\d+]/g,"");if(i.replace(/\+/g,"").length>=10)return console.log("[WhatsApp] Número extraído:",i),i}}return console.log("[WhatsApp] No se pudo extraer número de teléfono"),null}function g(){console.log("[WhatsApp] Extrayendo nombre de contacto...");const e=document.querySelectorAll('header span[dir="auto"]');console.log('[WhatsApp] Buscando nombre en spans con dir="auto":',e.length);for(const t of e)if(t.textContent){const o=t.textContent.trim();if(/^\+?[\d\s()-]+$/.test(o)){console.log("[WhatsApp] Saltando número puro:",o);continue}if(/[a-zA-Z]/.test(o)&&o.length>0){const s=o.replace(/\+?[\d\s()-]+/g,"").trim();if(s.length>0)return console.log("[WhatsApp] Nombre extraído:",s),s}}return console.log("[WhatsApp] No se pudo extraer nombre"),null}function f(){console.log("[WhatsApp] Extrayendo chat ID...");const e=window.location.href.match(/\/(\d{10,15})(@|$)/);if(e&&e[1])return console.log("[WhatsApp] Chat ID extraído de URL:",e[1]),e[1];const t=document.querySelectorAll('header span[dir="auto"]');for(const o of t)if(o.textContent){const a=o.textContent.trim(),n=/\+?[\d\s()-]+/,s=a.match(n);if(s){const c=s[0].replace(/[^\d+]/g,"");if(c.replace(/\+/g,"").length>=10)return console.log("[WhatsApp] Chat ID generado desde número:",c),c}}return console.log("[WhatsApp] No se pudo extraer chat ID"),null}function x(){var o,a;console.log("[WhatsApp] Buscando último mensaje recibido...");const e=['.message-in span.selectable-text.copyable-text span[dir="ltr"]','.message-in span.selectable-text span[dir="ltr"]',".message-in ._ao3e.selectable-text.copyable-text span",".message-in div[data-pre-plain-text] span.selectable-text span"];for(const n of e){const s=document.querySelectorAll(n);if(console.log(`[WhatsApp] Selector "${n}": ${s.length} elementos`),s.length>0)for(let c=s.length-1;c>=0;c--){const r=(o=s[c].textContent)==null?void 0:o.trim();if(r&&r.length>0){const d=/^\d{1,2}:\d{2}(\s*(a\.\s*m\.|p\.\s*m\.|AM|PM))?\.?$/.test(r),h=/^(Enviado|Entregado|Le[íi]do|Visto)$/i.test(r),u=r.length<2&&!/[a-zA-Z0-9]/.test(r);if(!d&&!h&&!u)return console.log("[WhatsApp] Mensaje encontrado:",r.substring(0,100)),r;console.log("[WhatsApp] Texto filtrado (timestamp/status):",r)}}}console.log("[WhatsApp] Intentando método alternativo...");const t=document.querySelectorAll(".message-in");for(let n=t.length-1;n>=0;n--){const c=t[n].querySelectorAll('span[dir="ltr"]');for(const i of c){const r=(a=i.textContent)==null?void 0:a.trim();if(r&&r.length>3&&!/^\d{1,2}:\d{2}/.test(r))return console.log("[WhatsApp] Mensaje encontrado (alternativo):",r.substring(0,100)),r}}return console.log("[WhatsApp] No se encontró mensaje válido"),null}function A(){const e=m(),t=g(),o=f();return!e&&!o?null:{phone:e||"unknown",name:t||"Sin nombre",chatId:o||"unknown"}}const p=new URL(chrome.runtime.getURL("")).origin;let l=null;console.log("[AmersurChat] Content script cargado");function b(){return new Promise(e=>{const t=setInterval(()=>{const o=document.querySelector("#app");o&&o.childNodes.length>0&&(clearInterval(t),console.log("[AmersurChat] WhatsApp Web detectado"),e())},500)})}function y(){if(document.getElementById("amersurchat-sidebar")){console.log("[AmersurChat] Sidebar ya existe");return}console.log("[AmersurChat] Inyectando sidebar...");const e=document.createElement("div");e.id="amersurchat-overlay",e.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: calc(100% - 300px);
    height: 100vh;
    background: rgba(0, 0, 0, 0.2);
    z-index: 999998;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.3s ease;
  `;const t=document.createElement("div");t.id="amersurchat-sidebar",t.style.cssText=`
    position: fixed;
    top: 0;
    right: 0;
    width: 300px;
    height: 100vh;
    z-index: 999999;
    background: white;
    box-shadow: -2px 0 12px rgba(0, 0, 0, 0.2);
    transform: translateX(100%);
    transition: transform 0.3s ease;
  `,t.classList.add("amersurchat-hidden");const o=document.createElement("iframe");o.style.cssText=`
    width: 100%;
    height: 100%;
    border: none;
  `,o.src=chrome.runtime.getURL("sidebar.html"),l=o.contentWindow,o.addEventListener("load",()=>{l=o.contentWindow}),t.appendChild(o),document.body.appendChild(e),document.body.appendChild(t);const a=(i=!1)=>{!t.classList.contains("amersurchat-hidden")||i?(t.classList.add("amersurchat-hidden"),t.style.transform="translateX(100%)",e.style.opacity="0",e.style.pointerEvents="none",n.style.right="20px"):(t.classList.remove("amersurchat-hidden"),t.style.transform="translateX(0)",e.style.opacity="1",e.style.pointerEvents="auto",n.style.right="320px")};e.addEventListener("click",()=>a(!0));const n=document.createElement("button");n.id="amersurchat-toggle";const s=chrome.runtime.getURL("icons/icon48.png");n.innerHTML=`
    <img src="${s}" alt="Amersur CRM" style="width: 28px; height: 28px; object-fit: contain;" />
  `,n.title="Amersur CRM",n.style.cssText=`
    position: fixed;
    top: 20px;
    right: 20px;
    width: 44px;
    height: 44px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    cursor: pointer;
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
    z-index: 999998;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
  `,n.addEventListener("mouseenter",()=>{n.style.transform="scale(1.1)",n.style.boxShadow="0 6px 16px rgba(102, 126, 234, 0.6)"}),n.addEventListener("mouseleave",()=>{n.style.transform="scale(1)",n.style.boxShadow="0 4px 12px rgba(102, 126, 234, 0.4)"}),n.addEventListener("click",()=>a());const c=document.createElement("div");c.id="amersurchat-badge",c.style.cssText=`
    position: absolute;
    top: -4px;
    right: -4px;
    min-width: 20px;
    height: 20px;
    border-radius: 10px;
    background: #ef4444;
    color: white;
    font-size: 11px;
    font-weight: bold;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 0 6px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
    border: 2px solid white;
  `,n.appendChild(c),document.body.appendChild(n),console.log("[AmersurChat] Sidebar inyectado correctamente")}function C(e){const t=document.getElementById("amersurchat-badge");t&&(e>0?(t.textContent=e>9?"9+":e.toString(),t.style.display="flex",console.log(`[AmersurChat] Badge actualizado: ${e} pendiente(s)`)):t.style.display="none")}b().then(()=>{y()});function E(e){try{console.log("[AmersurChat] Insertando texto en WhatsApp:",e.substring(0,50)+"...");const t=document.querySelector('[contenteditable="true"][data-tab="10"]');return t?(t.focus(),document.execCommand("insertText",!1,e),(!t.textContent||t.textContent.trim()==="")&&(t.textContent=e,t.dispatchEvent(new Event("input",{bubbles:!0})),t.dispatchEvent(new Event("change",{bubbles:!0}))),console.log("[AmersurChat] Texto insertado exitosamente"),!0):(console.error("[AmersurChat] No se encontró el input de WhatsApp"),!1)}catch(t){return console.error("[AmersurChat] Error insertando texto:",t),!1}}window.addEventListener("message",e=>{if(e.origin!==p||!e.data||typeof e.data!="object"||l&&e.source!==l)return;console.log("[AmersurChat] Mensaje recibido:",e.data.type,"desde extensión");const t=o=>{e.source&&typeof e.source.postMessage=="function"?e.source.postMessage(o,p):console.warn("[AmersurChat] No se pudo responder al mensaje (sin fuente válida)")};if(e.data.type==="AMERSURCHAT_GET_CONTACT"){console.log("[AmersurChat] Solicitando información del contacto...");const o=A();console.log("[AmersurChat] Contacto extraído:",o),t({type:"AMERSURCHAT_CONTACT_INFO",contact:o})}if(e.data.type==="AMERSURCHAT_INSERT_TEMPLATE"){console.log("[AmersurChat] Insertando plantilla en WhatsApp");const{text:o}=e.data;if(o){const a=E(o);t({type:"AMERSURCHAT_TEMPLATE_INSERTED",success:a})}}if(e.data.type==="AMERSURCHAT_UPDATE_BADGE"){console.log("[AmersurChat] Actualizando badge");const{count:o}=e.data;typeof o=="number"&&C(o)}if(e.data.type==="AMERSURCHAT_GET_LAST_MESSAGE"){const o=x();t({type:"AMERSURCHAT_LAST_MESSAGE",message:o})}});
