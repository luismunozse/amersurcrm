console.log("[AmersurChat] Content script cargado");function s(){return new Promise(t=>{const r=setInterval(()=>{const e=document.querySelector("#app");e&&e.childNodes.length>0&&(clearInterval(r),console.log("[AmersurChat] WhatsApp Web detectado"),t())},500)})}function n(){if(document.getElementById("amersurchat-sidebar")){console.log("[AmersurChat] Sidebar ya existe");return}console.log("[AmersurChat] Inyectando sidebar...");const t=document.createElement("div");t.id="amersurchat-sidebar",t.style.cssText=`
    position: fixed;
    top: 0;
    right: 0;
    width: 360px;
    height: 100vh;
    z-index: 999999;
    background: white;
    box-shadow: -2px 0 8px rgba(0, 0, 0, 0.15);
    transform: translateX(100%);
    transition: transform 0.3s ease;
  `,t.classList.add("amersurchat-hidden");const r=document.createElement("iframe");r.style.cssText=`
    width: 100%;
    height: 100%;
    border: none;
  `,r.src=chrome.runtime.getURL("sidebar.html"),t.appendChild(r),document.body.appendChild(t);const e=document.createElement("button");e.id="amersurchat-toggle",e.innerHTML=`
    <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
      <path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4V8l8 5 8-5v10zm-8-7L4 6h16l-8 5z"/>
    </svg>
  `,e.style.cssText=`
    position: fixed;
    top: 20px;
    right: 20px;
    width: 48px;
    height: 48px;
    border-radius: 50%;
    background: #25D366;
    color: white;
    border: none;
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
    z-index: 999998;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s;
  `,e.addEventListener("mouseenter",()=>{e.style.transform="scale(1.1)"}),e.addEventListener("mouseleave",()=>{e.style.transform="scale(1)"}),e.addEventListener("click",()=>{t.classList.contains("amersurchat-hidden")?(t.classList.remove("amersurchat-hidden"),t.style.transform="translateX(0)",e.style.right="380px"):(t.classList.add("amersurchat-hidden"),t.style.transform="translateX(100%)",e.style.right="20px")}),document.body.appendChild(e),console.log("[AmersurChat] Sidebar inyectado correctamente")}s().then(()=>{n()});window.addEventListener("message",t=>{if(t.source===window&&t.data.type==="AMERSURCHAT_GET_CONTACT"){const{extractContactInfo:r}=require("./lib/whatsapp"),e=r();window.postMessage({type:"AMERSURCHAT_CONTACT_INFO",contact:e},"*")}});
