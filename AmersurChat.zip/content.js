function l(){console.log("[WhatsApp] Extrayendo número de teléfono..."),console.log("[WhatsApp] URL actual:",window.location.href);const e=window.location.href.match(/\/(\d{10,15})(@|$)/);if(e&&e[1])return console.log("[WhatsApp] Número extraído de URL:",e[1]),"+"+e[1];const o=document.querySelector('[data-testid="conversation-info-header"]');if(o){console.log("[WhatsApp] Header encontrado, buscando número en atributos...");const a=o.getAttribute("aria-label");if(a){console.log("[WhatsApp] aria-label encontrado:",a);const r=a.match(/\+?[\d\s()-]+/);if(r&&r[0].replace(/[^\d]/g,"").length>=10){const n=r[0].replace(/[^\d+]/g,"");return console.log("[WhatsApp] Número extraído de aria-label:",n),n}}}const t=document.querySelectorAll('header span[dir="auto"]');console.log('[WhatsApp] Spans con dir="auto" encontrados:',t.length);for(const a of t)if(a.textContent){const r=a.textContent.trim();console.log("[WhatsApp] Analizando span:",r);const n=/\+?[\d\s()-]+/,s=r.match(n);if(s){const c=s[0].replace(/[^\d+]/g,"");if(c.replace(/\+/g,"").length>=10)return console.log("[WhatsApp] Número extraído:",c),c}}return console.log("[WhatsApp] No se pudo extraer número de teléfono"),null}function d(){console.log("[WhatsApp] Extrayendo nombre de contacto...");const e=document.querySelectorAll('header span[dir="auto"]');console.log('[WhatsApp] Buscando nombre en spans con dir="auto":',e.length);for(const o of e)if(o.textContent){const t=o.textContent.trim();if(/^\+?[\d\s()-]+$/.test(t)){console.log("[WhatsApp] Saltando número puro:",t);continue}if(/[a-zA-Z]/.test(t)&&t.length>0){const n=t.replace(/\+?[\d\s()-]+/g,"").trim();if(n.length>0)return console.log("[WhatsApp] Nombre extraído:",n),n}}return console.log("[WhatsApp] No se pudo extraer nombre"),null}function i(){console.log("[WhatsApp] Extrayendo chat ID...");const e=window.location.href.match(/\/(\d{10,15})(@|$)/);if(e&&e[1])return console.log("[WhatsApp] Chat ID extraído de URL:",e[1]),e[1];const o=document.querySelectorAll('header span[dir="auto"]');for(const t of o)if(t.textContent){const a=t.textContent.trim(),r=/\+?[\d\s()-]+/,n=a.match(r);if(n){const s=n[0].replace(/[^\d+]/g,"");if(s.replace(/\+/g,"").length>=10)return console.log("[WhatsApp] Chat ID generado desde número:",s),s}}return console.log("[WhatsApp] No se pudo extraer chat ID"),null}function h(){const e=l(),o=d(),t=i();return!e&&!t?null:{phone:e||"unknown",name:o||"Sin nombre",chatId:t||"unknown"}}console.log("[AmersurChat] Content script cargado");function p(){return new Promise(e=>{const o=setInterval(()=>{const t=document.querySelector("#app");t&&t.childNodes.length>0&&(clearInterval(o),console.log("[AmersurChat] WhatsApp Web detectado"),e())},500)})}function u(){if(document.getElementById("amersurchat-sidebar")){console.log("[AmersurChat] Sidebar ya existe");return}console.log("[AmersurChat] Inyectando sidebar...");const e=document.createElement("div");e.id="amersurchat-sidebar",e.style.cssText=`
    position: fixed;
    top: 0;
    right: 0;
    width: 360px;
    height: 100vh;
    z-index: 999999;
    background: white;
    box-shadow: -2px 0 8px rgba(0, 0, 0, 0.15);
    transform: translateX(100%);
    transition: transform 0.3s ease;
  `,e.classList.add("amersurchat-hidden");const o=document.createElement("iframe");o.style.cssText=`
    width: 100%;
    height: 100%;
    border: none;
  `,o.src=chrome.runtime.getURL("sidebar.html"),e.appendChild(o),document.body.appendChild(e);const t=document.createElement("button");t.id="amersurchat-toggle",t.innerHTML=`
    <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
      <path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4V8l8 5 8-5v10zm-8-7L4 6h16l-8 5z"/>
    </svg>
  `,t.style.cssText=`
    position: fixed;
    top: 20px;
    right: 20px;
    width: 48px;
    height: 48px;
    border-radius: 50%;
    background: #25D366;
    color: white;
    border: none;
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
    z-index: 999998;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s;
  `,t.addEventListener("mouseenter",()=>{t.style.transform="scale(1.1)"}),t.addEventListener("mouseleave",()=>{t.style.transform="scale(1)"}),t.addEventListener("click",()=>{e.classList.contains("amersurchat-hidden")?(e.classList.remove("amersurchat-hidden"),e.style.transform="translateX(0)",t.style.right="380px"):(e.classList.add("amersurchat-hidden"),e.style.transform="translateX(100%)",t.style.right="20px")}),document.body.appendChild(t),console.log("[AmersurChat] Sidebar inyectado correctamente")}p().then(()=>{u()});window.addEventListener("message",e=>{if(console.log("[AmersurChat] Mensaje recibido:",e.data.type,"desde:",e.origin),e.data.type==="AMERSURCHAT_GET_CONTACT"){console.log("[AmersurChat] Solicitando información del contacto...");const o=h();console.log("[AmersurChat] Contacto extraído:",o),e.source&&e.source!==window?e.source.postMessage({type:"AMERSURCHAT_CONTACT_INFO",contact:o},"*"):window.postMessage({type:"AMERSURCHAT_CONTACT_INFO",contact:o},"*")}});
