const h={debug:(...e)=>{},warn:(e,...t)=>console.warn(`[WhatsApp] ${e}`,...t),error:(e,t)=>console.error(`[WhatsApp] ${e}`,t||"")},d={chatHeader:["header",'[data-testid="conversation-header"]',"#main header"],headerContactSpan:['[data-testid="conversation-info-header"] span[dir="auto"]','[data-testid="conversation-title"] span[dir="auto"]','header span[title][dir="auto"]','header span[dir="auto"]'],headerInfoButton:['[data-testid="conversation-info-header"]','[data-testid="contact-info-drawer"]','header [role="button"]'],incomingMessage:['[data-testid="msg-container"].message-in',".message-in",'div[data-id][class*="message-in"]'],messageText:["span.selectable-text.copyable-text span",'span.selectable-text span[dir="ltr"]',"span.selectable-text span",'span[dir="ltr"]'],messageMeta:["[data-pre-plain-text]"],selectableText:["span.selectable-text","span.selectable-text span",".selectable-text"],chatInput:['[data-testid="conversation-compose-box-input"]','footer [contenteditable="true"][data-tab="10"]','footer [contenteditable="true"]','[contenteditable="true"][data-tab="10"]','div[contenteditable="true"][role="textbox"]']};function p(e,t=document){for(const n of e)try{const a=t.querySelector(n);if(a)return a}catch{}return null}function u(e,t=document){for(const n of e)try{const a=t.querySelectorAll(n);if(a.length>0)return Array.from(a)}catch{}return[]}function b(){const e=window.location.href.match(/\/(\d{10,15})(@|$)/);if(e!=null&&e[1])return"+"+e[1];const t=p(d.headerInfoButton);if(t){const r=(t.getAttribute("aria-label")||t.getAttribute("title")||"").match(/\+?[\d\s()-]+/);if(r&&r[0].replace(/[^\d]/g,"").length>=10)return r[0].replace(/[^\d+]/g,"")}const n=x();return n||null}function x(){var t;const e=u(d.headerContactSpan);for(const n of e){const a=(t=n.textContent)==null?void 0:t.trim();if(!a)continue;const r=a.match(/\+?[\d\s()-]+/);if(!r)continue;const s=r[0].replace(/[^\d+]/g,"");if(s.replace(/\+/g,"").length>=10)return s.startsWith("+")?s:"+"+s}return null}function C(e){const t=(e||"").replace(/^~\s*/,"").trim();return!t||/^\+?[\d\s()-]+$/.test(t)||!/[a-zA-ZáéíóúñÁÉÍÓÚÑ]/.test(t)?null:t}function y(){var n;const e=u(d.headerContactSpan),t=C((n=e[0])==null?void 0:n.textContent);return t||null}function A(){const e=window.location.href.match(/\/(\d{10,15})(@|$)/);if(e!=null&&e[1])return e[1];const t=x();return t?t.replace(/[^\d]/g,""):null}function E(e){return(e||"").replace(/\D/g,"")}function T(e){const t=(e||"").match(/\]\s*(.*?):\s*$/);return t?t[1].trim():""}function w(e,t,n){if(!e)return!1;const a=E(e);return t&&a.length>=8?a.slice(-8)===t.slice(-8):!!n&&e===n}function S(e){return e.replace(/\s*\d{1,2}:\d{2}\s*(a\.?\s*m\.?|p\.?\s*m\.?|AM|PM)?\s*$/i,"").trim()}function v(){var r;const e=E(b()),t=(y()||"").trim(),n=u(d.messageMeta);for(let s=n.length-1;s>=0;s--){const i=T(n[s].getAttribute("data-pre-plain-text"));if(!w(i,e,t))continue;const c=p(d.selectableText,n[s])||n[s],o=S((c.textContent||"").trim());if(o&&g(o))return o}const a=u(d.incomingMessage);for(let s=a.length-1;s>=Math.max(0,a.length-5);s--){const i=u(d.messageText,a[s]);for(const c of i){const o=(r=c.textContent)==null?void 0:r.trim();if(o&&g(o))return o}}return h.warn(`getLastReceivedMessage: no se encontró mensaje entrante. Bloques data-pre-plain-text: ${n.length}, contacto: ${e||t||"desconocido"}. ¿Cambió el DOM de WhatsApp Web? Revisar SELECTORS.messageMeta/selectableText.`),null}function g(e){return!(e.length<2||/^\d{1,2}:\d{2}(\s*(a\.\s*m\.|p\.\s*m\.|AM|PM))?\.?$/.test(e)||/^(Enviado|Entregado|Le[íi]do|Visto|Delivered|Read|Sent)$/i.test(e)||/^(Ayer|Hoy|Yesterday|Today)$/i.test(e))}function m(){const e=b(),t=y(),n=A();return!e&&!n?null:{phone:e||"unknown",name:t||"Sin nombre",chatId:n||"unknown"}}function R(e){var t;try{const n=p(d.chatInput);if(!n)return h.warn("No se encontró el input de WhatsApp con ningún selector"),!1;if(n.focus(),document.execCommand("insertText",!1,e)&&((t=n.textContent)!=null&&t.includes(e.substring(0,20))))return!0;const r=new InputEvent("input",{bubbles:!0,cancelable:!0,inputType:"insertText",data:e});return n.textContent=e,n.dispatchEvent(r),n.dispatchEvent(new Event("change",{bubbles:!0})),!0}catch(n){return h.error("Error insertando texto en WhatsApp",n instanceof Error?n:void 0),!1}}function M(e){let t=null,n=null,a=!1;const r=()=>{if(a)return;const c=m(),o=(c==null?void 0:c.chatId)||null;o!==t&&(t=o,e(c))};r();const s=p(d.chatHeader);s&&(n=new MutationObserver(r),n.observe(s,{childList:!0,subtree:!0,characterData:!0}));const i=setInterval(r,3e3);return()=>{a=!0,clearInterval(i),n==null||n.disconnect()}}const f=new URL(chrome.runtime.getURL("")).origin;let l=null;function I(){if(!l)return;const e=m();l.postMessage({type:"AMERSURCHAT_CONTACT_CHANGED",contact:e},f)}function L(){return new Promise(e=>{const t=setInterval(()=>{const n=document.querySelector("#app");n&&n.childNodes.length>0&&(clearInterval(t),e())},500)})}function _(){if(document.getElementById("amersurchat-sidebar"))return;const e=document.createElement("div");e.id="amersurchat-overlay",e.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: calc(100% - 300px);
    height: 100vh;
    background: rgba(0, 0, 0, 0.2);
    z-index: 999998;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.3s ease;
  `;const t=document.createElement("div");t.id="amersurchat-sidebar",t.style.cssText=`
    position: fixed;
    top: 0;
    right: 0;
    width: 300px;
    height: 100vh;
    z-index: 999999;
    background: white;
    box-shadow: -2px 0 12px rgba(0, 0, 0, 0.2);
    transform: translateX(100%);
    transition: transform 0.3s ease;
  `,t.classList.add("amersurchat-hidden");const n=document.createElement("iframe");n.style.cssText=`
    width: 100%;
    height: 100%;
    border: none;
  `,n.src=chrome.runtime.getURL("sidebar.html"),l=n.contentWindow,n.addEventListener("load",()=>{l=n.contentWindow}),t.appendChild(n),document.body.appendChild(e),document.body.appendChild(t);const a=(c=!1)=>{!t.classList.contains("amersurchat-hidden")||c?(t.classList.add("amersurchat-hidden"),t.style.transform="translateX(100%)",e.style.opacity="0",e.style.pointerEvents="none",r.style.right="20px"):(t.classList.remove("amersurchat-hidden"),t.style.transform="translateX(0)",e.style.opacity="1",e.style.pointerEvents="auto",r.style.right="320px")};e.addEventListener("click",()=>a(!0));const r=document.createElement("button");r.id="amersurchat-toggle";const s=chrome.runtime.getURL("icons/icon48.png");r.innerHTML=`
    <img src="${s}" alt="Amersur CRM" style="width: 28px; height: 28px; object-fit: contain;" />
  `,r.title="Amersur CRM",r.style.cssText=`
    position: fixed;
    top: 20px;
    right: 20px;
    width: 44px;
    height: 44px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    cursor: pointer;
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
    z-index: 999998;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
  `,r.addEventListener("mouseenter",()=>{r.style.transform="scale(1.1)",r.style.boxShadow="0 6px 16px rgba(102, 126, 234, 0.6)"}),r.addEventListener("mouseleave",()=>{r.style.transform="scale(1)",r.style.boxShadow="0 4px 12px rgba(102, 126, 234, 0.4)"}),r.addEventListener("click",()=>a());const i=document.createElement("div");i.id="amersurchat-badge",i.style.cssText=`
    position: absolute;
    top: -4px;
    right: -4px;
    min-width: 20px;
    height: 20px;
    border-radius: 10px;
    background: #ef4444;
    color: white;
    font-size: 11px;
    font-weight: bold;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 0 6px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
    border: 2px solid white;
  `,r.appendChild(i),document.body.appendChild(r)}function H(e){const t=document.getElementById("amersurchat-badge");t&&(e>0?(t.textContent=e>9?"9+":e.toString(),t.style.display="flex"):t.style.display="none")}L().then(()=>{_(),M(()=>I())});window.addEventListener("message",e=>{if(e.origin!==f||!e.data||typeof e.data!="object"||l&&e.source!==l)return;const t=n=>{e.source&&typeof e.source.postMessage=="function"&&e.source.postMessage(n,f)};switch(e.data.type){case"AMERSURCHAT_GET_CONTACT":{const n=m();t({type:"AMERSURCHAT_CONTACT_INFO",contact:n});break}case"AMERSURCHAT_INSERT_TEMPLATE":{const{text:n}=e.data;if(n){const a=R(n);t({type:"AMERSURCHAT_TEMPLATE_INSERTED",success:a})}break}case"AMERSURCHAT_UPDATE_BADGE":{const{count:n}=e.data;typeof n=="number"&&H(n);break}case"AMERSURCHAT_GET_LAST_MESSAGE":{const n=v();t({type:"AMERSURCHAT_LAST_MESSAGE",message:n});break}}});
