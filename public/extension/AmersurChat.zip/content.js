function i(){console.log("[WhatsApp] Extrayendo número de teléfono..."),console.log("[WhatsApp] URL actual:",window.location.href);const e=window.location.href.match(/\/(\d{10,15})(@|$)/);if(e&&e[1])return console.log("[WhatsApp] Número extraído de URL:",e[1]),"+"+e[1];const t=document.querySelector('[data-testid="conversation-info-header"]');if(t){console.log("[WhatsApp] Header encontrado, buscando número en atributos...");const s=t.getAttribute("aria-label");if(s){console.log("[WhatsApp] aria-label encontrado:",s);const o=s.match(/\+?[\d\s()-]+/);if(o&&o[0].replace(/[^\d]/g,"").length>=10){const a=o[0].replace(/[^\d+]/g,"");return console.log("[WhatsApp] Número extraído de aria-label:",a),a}}}const n=document.querySelectorAll('header span[dir="auto"]');console.log('[WhatsApp] Spans con dir="auto" encontrados:',n.length);for(const s of n)if(s.textContent){const o=s.textContent.trim();console.log("[WhatsApp] Analizando span:",o);const a=/\+?[\d\s()-]+/,r=o.match(a);if(r){const c=r[0].replace(/[^\d+]/g,"");if(c.replace(/\+/g,"").length>=10)return console.log("[WhatsApp] Número extraído:",c),c}}return console.log("[WhatsApp] No se pudo extraer número de teléfono"),null}function l(){console.log("[WhatsApp] Extrayendo nombre de contacto...");const e=document.querySelectorAll('header span[dir="auto"]');console.log('[WhatsApp] Buscando nombre en spans con dir="auto":',e.length);for(const t of e)if(t.textContent){const n=t.textContent.trim();if(/^\+?[\d\s()-]+$/.test(n)){console.log("[WhatsApp] Saltando número puro:",n);continue}if(/[a-zA-Z]/.test(n)&&n.length>0){const a=n.replace(/\+?[\d\s()-]+/g,"").trim();if(a.length>0)return console.log("[WhatsApp] Nombre extraído:",a),a}}return console.log("[WhatsApp] No se pudo extraer nombre"),null}function d(){console.log("[WhatsApp] Extrayendo chat ID...");const e=window.location.href.match(/\/(\d{10,15})(@|$)/);if(e&&e[1])return console.log("[WhatsApp] Chat ID extraído de URL:",e[1]),e[1];const t=document.querySelectorAll('header span[dir="auto"]');for(const n of t)if(n.textContent){const s=n.textContent.trim(),o=/\+?[\d\s()-]+/,a=s.match(o);if(a){const r=a[0].replace(/[^\d+]/g,"");if(r.replace(/\+/g,"").length>=10)return console.log("[WhatsApp] Chat ID generado desde número:",r),r}}return console.log("[WhatsApp] No se pudo extraer chat ID"),null}function h(){const e=i(),t=l(),n=d();return!e&&!n?null:{phone:e||"unknown",name:t||"Sin nombre",chatId:n||"unknown"}}console.log("[AmersurChat] Content script cargado");function p(){return new Promise(e=>{const t=setInterval(()=>{const n=document.querySelector("#app");n&&n.childNodes.length>0&&(clearInterval(t),console.log("[AmersurChat] WhatsApp Web detectado"),e())},500)})}function u(){if(document.getElementById("amersurchat-sidebar")){console.log("[AmersurChat] Sidebar ya existe");return}console.log("[AmersurChat] Inyectando sidebar...");const e=document.createElement("div");e.id="amersurchat-overlay",e.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100vh;
    background: rgba(0, 0, 0, 0.3);
    z-index: 999998;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.3s ease;
  `;const t=document.createElement("div");t.id="amersurchat-sidebar",t.style.cssText=`
    position: fixed;
    top: 0;
    right: 0;
    width: 300px;
    height: 100vh;
    z-index: 999999;
    background: white;
    box-shadow: -2px 0 12px rgba(0, 0, 0, 0.2);
    transform: translateX(100%);
    transition: transform 0.3s ease;
  `,t.classList.add("amersurchat-hidden");const n=document.createElement("iframe");n.style.cssText=`
    width: 100%;
    height: 100%;
    border: none;
  `,n.src=chrome.runtime.getURL("sidebar.html"),t.appendChild(n),document.body.appendChild(e),document.body.appendChild(t);const s=(a=!1)=>{!t.classList.contains("amersurchat-hidden")||a?(t.classList.add("amersurchat-hidden"),t.style.transform="translateX(100%)",e.style.opacity="0",e.style.pointerEvents="none",o.style.right="20px"):(t.classList.remove("amersurchat-hidden"),t.style.transform="translateX(0)",e.style.opacity="1",e.style.pointerEvents="auto",o.style.right="320px")};e.addEventListener("click",()=>s(!0));const o=document.createElement("button");o.id="amersurchat-toggle",o.innerHTML=`
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
      <line x1="9" y1="10" x2="15" y2="10"/>
      <line x1="9" y1="14" x2="13" y2="14"/>
    </svg>
  `,o.title="Amersur CRM",o.style.cssText=`
    position: fixed;
    top: 20px;
    right: 20px;
    width: 44px;
    height: 44px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    cursor: pointer;
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
    z-index: 999998;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
  `,o.addEventListener("mouseenter",()=>{o.style.transform="scale(1.1)",o.style.boxShadow="0 6px 16px rgba(102, 126, 234, 0.6)"}),o.addEventListener("mouseleave",()=>{o.style.transform="scale(1)",o.style.boxShadow="0 4px 12px rgba(102, 126, 234, 0.4)"}),o.addEventListener("click",()=>s()),document.body.appendChild(o),console.log("[AmersurChat] Sidebar inyectado correctamente")}p().then(()=>{u()});window.addEventListener("message",e=>{if(console.log("[AmersurChat] Mensaje recibido:",e.data.type,"desde:",e.origin),e.data.type==="AMERSURCHAT_GET_CONTACT"){console.log("[AmersurChat] Solicitando información del contacto...");const t=h();console.log("[AmersurChat] Contacto extraído:",t),e.source&&e.source!==window?e.source.postMessage({type:"AMERSURCHAT_CONTACT_INFO",contact:t},"*"):window.postMessage({type:"AMERSURCHAT_CONTACT_INFO",contact:t},"*")}});
